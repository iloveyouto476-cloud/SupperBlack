# SupperBlack — A0 APK Feasibility Test

Source of Truth: `SupperBlack_Web_MVP_W1.zip` (Web MVP vNext Fixed 2), inspected 2026-08-17.

This project is intentionally a minimal Android WebView wrapper. The Web UI remains the source of truth.

## Scope
- Android App -> WebView -> `assets/www/index.html`
- Bundles the latest `index.html`, `style.css`, and `app.js` without redesigning the Web UI.
- No Android Bridge.
- No native background audio.
- No database/backend/authentication.
- No native rewrite of Search, Music, YouTube, or Website.

## Build
Use Android Studio or the Android Gradle toolchain.

- Android Gradle Plugin: 9.3.0
- Gradle: 9.5.0
- compileSdk: 37
- targetSdk: 37
- minSdk: 24
- AndroidX WebKit: 1.16.0

## A0 Test Goal
Install the debug APK on a physical Android device and verify the existing Web MVP:
- Home
- Global Search
- Results
- YouTube
- Music
- Website
- Back
- Home
- YouTube player/fullscreen behavior
- Website viewer behavior
- Voice fallback/behavior in WebView

A0 is a feasibility test, not the final release APK.
