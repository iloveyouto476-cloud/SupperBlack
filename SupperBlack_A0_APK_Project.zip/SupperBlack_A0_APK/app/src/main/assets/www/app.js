const state = {
  page: "home",
  history: [],
  query: "",
  youtubeResults: [],
  musicResults: [],
  websiteResults: [],
  sourceErrors: {youtube:"", music:"", website:""},
  currentVideo: null,
  currentWebsite: null,
  youtubeFilter: "video",
  searchRequest: 0,
  nowPlaying: null
};

const $ = (s) => document.querySelector(s);
const view = $("#view");
const toastEl = $("#toast");
const settingsDialog = $("#settingsDialog");
const apiKeyInput = $("#apiKeyInput");

function esc(s=""){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}
function toast(msg){
  toastEl.textContent=msg; toastEl.classList.add("show");
  clearTimeout(window.__toast); window.__toast=setTimeout(()=>toastEl.classList.remove("show"),2600);
}
// ระบบนำทางกลาง — ทุกจุดที่ต้องเปลี่ยนหน้าต้องผ่านฟังก์ชันนี้เท่านั้น
// (ห้ามเซ็ต state.page="..." ตรงๆ ที่อื่นอีก เพื่อให้ history ถูกต้องเสมอ)
function goTo(page){
  if(state.page===page)return;
  state.history.push(state.page);
  state.page=page;
}
function pushPage(page){
  goTo(page);
  render();
}
function goBack(){
  const prev=state.history.pop();
  state.page=prev||"home";
  render();
}
function goHome(){
  state.history=[];
  state.page="home";
  state.query="";
  state.currentVideo=null;
  state.currentWebsite=null;
  state.youtubeResults=[];
  state.musicResults=[];
  state.websiteResults=[];
  state.sourceErrors={youtube:"", music:"", website:""};
  render();
}
$("#backBtn").onclick=goBack;
$("#homeBtn").onclick=goHome;
$("#settingsBtn").onclick=()=>{
  apiKeyInput.value=localStorage.getItem("sb_youtube_api_key")||"";
  settingsDialog.showModal();
};
$("#saveKeyBtn").onclick=()=>{
  const key=apiKeyInput.value.trim();
  if(key)localStorage.setItem("sb_youtube_api_key",key); else localStorage.removeItem("sb_youtube_api_key");
  settingsDialog.close(); toast(key?"บันทึก YouTube API Key แล้ว":"ลบ YouTube API Key แล้ว");
};
$("#clearKeyBtn").onclick=()=>{
  localStorage.removeItem("sb_youtube_api_key"); apiKeyInput.value=""; toast("ลบ API Key แล้ว");
};

function searchBox({placeholder="ค้นหาอะไรก็ได้...", value="", mode="global"}={}){
  return `<div class="search-wrap">
    <input id="searchInput" value="${esc(value)}" placeholder="${esc(placeholder)}" autocomplete="off" enterkeyhint="search">
    <button id="micBtn" class="mic-btn" aria-label="รับเสียง">🎙</button>
  </div>
  <button id="searchBtn" class="primary-search">ค้นหา</button>`;
}

function bindSearch(mode){
  const input=$("#searchInput"), btn=$("#searchBtn"), mic=$("#micBtn");
  const run=()=>{const q=input.value.trim(); if(!q){toast("พิมพ์คำค้นหาก่อน");return;} if(mode==="global")globalSearch(q); if(mode==="youtube")youtubeSearch(q); if(mode==="music")musicSearch(q); if(mode==="website")websiteSearch(q);};
  btn.onclick=run; input.addEventListener("keydown",e=>{if(e.key==="Enter")run()});
  bindVoice(input,mic);
}
function bindVoice(input,btn){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){btn.onclick=()=>toast("Browser นี้ไม่รองรับการรับเสียง");return;}
  let rec=null;
  btn.onclick=()=>{
    if(rec){try{rec.stop()}catch{} rec=null; btn.classList.remove("listening"); return;}
    rec=new SR(); rec.lang="th-TH"; rec.continuous=false; rec.interimResults=false; rec.maxAlternatives=1;
    rec.onstart=()=>{btn.classList.add("listening");toast("กำลังฟัง... พูดได้เลย")};
    rec.onresult=e=>{input.value=e.results[0][0].transcript};
    rec.onerror=e=>{toast(e.error==="not-allowed"?"ไม่ได้รับอนุญาตไมโครโฟน":`เสียงไม่สำเร็จ: ${e.error}`)};
    rec.onend=()=>{btn.classList.remove("listening");rec=null};
    try{rec.start()}catch{btn.classList.remove("listening");rec=null}
  };
}

async function globalSearch(q){
  const request=++state.searchRequest;
  state.query=q; goTo("results");
  state.youtubeResults=[]; state.musicResults=[]; state.websiteResults=[];
  state.sourceErrors={youtube:"", music:"", website:""};
  renderResultsLoading();
  const [yt,music,sites]=await Promise.allSettled([fetchYouTube(q),fetchMusic(q),fetchWebsites(q)]);
  if(request!==state.searchRequest || state.page!=="results")return;
  state.youtubeResults=yt.status==="fulfilled"?yt.value:[];
  state.musicResults=music.status==="fulfilled"?music.value:[];
  state.websiteResults=sites.status==="fulfilled"?sites.value:[];
  state.sourceErrors.youtube=yt.status==="rejected"?(yt.reason?.message||"ค้นหา YouTube ไม่สำเร็จ"):"";
  state.sourceErrors.music=music.status==="rejected"?(music.reason?.message||"ค้นหาเพลงไม่สำเร็จ"):"";
  state.sourceErrors.website=sites.status==="rejected"?(sites.reason?.message||"ค้นหาเว็บไซต์ไม่สำเร็จ"):"";
  renderResults();
}
async function youtubeSearch(q){
  const request=++state.searchRequest;
  state.query=q; goTo("youtube"); renderYoutubePage();
  const key=localStorage.getItem("sb_youtube_api_key");
  if(!key){
    $("#resultsArea").innerHTML=`<div class="empty">ยังไม่ได้ใส่ YouTube Data API Key<br><br>
      <button class="btn primary" id="openSettings">ตั้งค่า API Key</button>
      <br><small>หรือเปิดผลค้นหาบน YouTube โดยตรง</small><br><br>
      <button class="btn secondary" id="openYT">เปิด YouTube</button></div>`;
    $("#openSettings").onclick=()=>$("#settingsBtn").click();
    $("#openYT").onclick=()=>window.open("https://www.youtube.com/results?search_query="+encodeURIComponent(q),"_blank","noopener");
    return;
  }
  if(!q){return;}
  $("#resultsArea").innerHTML=`<div class="loading">กำลังค้นหา…</div>`;
  try{
    const results=await fetchYouTube(q);
    if(request!==state.searchRequest || state.page!=="youtube")return;
    state.youtubeResults=results; state.sourceErrors.youtube=""; renderYoutubeResults();
  }
  catch(e){
    if(request!==state.searchRequest || state.page!=="youtube")return;
    state.sourceErrors.youtube=e.message||"ค้นหา YouTube ไม่สำเร็จ";
    $("#resultsArea").innerHTML=`<div class="empty">ค้นหา YouTube ไม่สำเร็จ: ${esc(e.message)}</div>`;
  }
}
async function fetchYouTube(q){
  const key=localStorage.getItem("sb_youtube_api_key");
  if(!key) return [];
  const url="https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&maxResults=12&q="+encodeURIComponent(q)+"&regionCode=TH&relevanceLanguage=th&key="+encodeURIComponent(key);
  const r=await fetch(url); const data=await r.json();
  if(!r.ok) throw new Error(data?.error?.message||"YouTube API error");
  return (data.items||[]).map(x=>({id:x.id.videoId,title:x.snippet.title,channel:x.snippet.channelTitle,thumb:x.snippet.thumbnails?.medium?.url||x.snippet.thumbnails?.default?.url,description:x.snippet.description}));
}
function renderYoutubeResults(){
  const area=$("#resultsArea"); if(!area)return;
  area.innerHTML=state.youtubeResults.length?state.youtubeResults.map(v=>`<article class="card result-card" data-video="${esc(v.id)}"><img class="thumb" src="${esc(v.thumb)}" alt=""><div class="result-body"><div class="result-title">${esc(v.title)}</div><div class="result-meta">${esc(v.channel)}</div></div><span class="arrow">›</span></article>`).join(""):`<div class="empty">ไม่พบวิดีโอ</div>`;
  area.querySelectorAll("[data-video]").forEach(el=>el.onclick=()=>openVideo(el.dataset.video));
}
function openVideo(id){
  const v=state.youtubeResults.find(x=>x.id===id); if(!v)return;
  state.currentVideo=v; pushPage("player");
}
function renderPlayer(){
  const v=state.currentVideo;
  if(!v){state.page="home";render();return;}
  view.innerHTML=`<section class="view">
    <div class="section-head"><h2>← YouTube Player</h2><span class="muted">แนวตั้ง / แนวนอน / Fullscreen</span></div>
    <div class="video-shell" id="videoShell"><iframe src="https://www.youtube.com/embed/${encodeURIComponent(v.id)}?playsinline=1&rel=0" title="${esc(v.title)}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowfullscreen></iframe></div>
    <div class="player-title">${esc(v.title)}</div><div class="player-meta">${esc(v.channel)}</div>
    <div class="player-actions"><button class="btn primary" id="fullBtn">⛶ Fullscreen</button><button class="btn secondary" id="openOriginal">เปิดใน YouTube</button></div>
  </section>`;
  $("#fullBtn").onclick=async()=>{
    const el=$("#videoShell");
    try{
      if(el.requestFullscreen)await el.requestFullscreen();
      if(screen.orientation?.lock)await screen.orientation.lock("landscape").catch(()=>{});
    }catch{toast("Fullscreen ไม่รองรับบน Browser นี้")}
  };
  $("#openOriginal").onclick=()=>window.open("https://www.youtube.com/watch?v="+encodeURIComponent(v.id),"_blank","noopener");
}
async function musicSearch(q){
  const request=++state.searchRequest;
  state.query=q; goTo("music"); renderMusicPage();
  if(!q){return;}
  $("#resultsArea").innerHTML=`<div class="loading">กำลังค้นหาเพลง…</div>`;
  try{
    const results=await fetchMusic(q);
    if(request!==state.searchRequest || state.page!=="music")return;
    state.musicResults=results; state.sourceErrors.music=""; renderMusicResults();
  }
  catch(e){
    if(request!==state.searchRequest || state.page!=="music")return;
    state.sourceErrors.music=e.message||"ค้นหาเพลงไม่สำเร็จ";
    $("#resultsArea").innerHTML=`<div class="empty">ค้นหาเพลงไม่สำเร็จ</div>`;
  }
}
async function fetchMusic(q){
  const run=async(country)=>{
    const url="https://itunes.apple.com/search?term="+encodeURIComponent(q)+"&entity=song&limit=15"+(country?"&country="+country:"");
    const r=await fetch(url); if(!r.ok)throw new Error("Music API error"); const d=await r.json();
    return (d.results||[]).map(x=>({id:x.trackId,title:x.trackName,artist:x.artistName,album:x.collectionName,cover:x.artworkUrl100,preview:x.previewUrl,store:x.trackViewUrl}));
  };
  let results=await run("TH");
  if(!results.length) results=await run(); // ถ้าสโตร์ไทยไม่มีผล ลองค้นแบบไม่จำกัดประเทศ
  return results;
}
function renderMusicResults(){
  const area=$("#resultsArea"); if(!area)return;
  area.innerHTML=state.musicResults.length?state.musicResults.map((m,i)=>musicCardHtml(m,i)).join(""):`<div class="empty">ไม่พบเพลง</div>`;
  bindMusicCards(area,state.musicResults);
}
function openProvider(p,m){
  // JOOX ไม่มี API/พารามิเตอร์ค้นหาที่ทางการรองรับ จึงไม่เดา URL — คัดลอกชื่อเพลงให้แปะเองแทน
  if(p==="joox"){
    const text=`${m.title} ${m.artist}`;
    if(navigator.clipboard?.writeText){
      navigator.clipboard.writeText(text).then(()=>toast("คัดลอกชื่อเพลงแล้ว วางในช่องค้นหา JOOX ได้เลย")).catch(()=>toast("ค้นหาต่อใน JOOX: "+text));
    }else{ toast("ค้นหาต่อใน JOOX: "+text); }
    window.open("https://www.joox.com/th/search","_blank","noopener");
    return;
  }
  const q=encodeURIComponent(`${m.title} ${m.artist}`);
  const urls={spotify:`https://open.spotify.com/search/${q}`,ytm:`https://music.youtube.com/search?q=${q}`};
  window.open(urls[p],"_blank","noopener");
}

// ---- Mini Player (เฟส 1: เว็บล้วน ไม่ background — ตามที่ล็อกไว้) ----
const miniPlayer=$("#miniPlayer"), mpAudio=$("#mpAudio"), mpCover=$("#mpCover"),
      mpTitle=$("#mpTitle"), mpArtist=$("#mpArtist"), mpToggle=$("#mpToggle"), mpClose=$("#mpClose");
function playTrack(m){
  state.nowPlaying=m;
  mpCover.src=m.cover||""; mpTitle.textContent=m.title; mpArtist.textContent=m.artist||"";
  miniPlayer.classList.remove("hidden");
  document.body.classList.add("has-mini-player");
  if(m.preview){
    mpAudio.src=m.preview; mpAudio.play().catch(()=>{}); mpToggle.textContent="❚❚"; mpToggle.disabled=false;
  }else{
    mpAudio.removeAttribute("src"); mpToggle.textContent="▶"; mpToggle.disabled=true;
    toast("เพลงนี้ไม่มีตัวอย่างเสียง ลองฟังต่อผ่านปุ่ม Provider ใต้การ์ด");
  }
}
mpToggle.onclick=()=>{
  if(!mpAudio.src)return;
  if(mpAudio.paused){mpAudio.play().catch(()=>{});mpToggle.textContent="❚❚";}
  else{mpAudio.pause();mpToggle.textContent="▶";}
};
mpAudio.addEventListener("ended",()=>mpToggle.textContent="▶");
mpClose.onclick=()=>{
  mpAudio.pause(); mpAudio.removeAttribute("src");
  miniPlayer.classList.add("hidden"); document.body.classList.remove("has-mini-player");
  state.nowPlaying=null;
};
function musicCardHtml(m,i){
  return `<article class="card music-row"><img class="cover" src="${esc(m.cover||"")}"><div class="result-body">
    <div class="result-title">${esc(m.title)}</div><div class="result-meta">${esc(m.artist)}${m.album?" • "+esc(m.album):""}</div>
    <button class="btn primary play-btn" data-i="${i}">${m.preview?"▶ ฟังตัวอย่าง":"▶ ไม่มีตัวอย่าง"}</button>
    <div class="provider-grid"><button class="provider spotify" data-p="spotify" data-i="${i}">Spotify</button><button class="provider joox" data-p="joox" data-i="${i}">JOOX</button><button class="provider ytm" data-p="ytm" data-i="${i}">YouTube Music</button></div>
  </div></article>`;
}
function bindMusicCards(container,list){
  container.querySelectorAll("[data-i]").forEach(el=>{
    const i=+el.dataset.i;
    if(el.classList.contains("play-btn")) el.onclick=()=>playTrack(list[i]);
    else if(el.dataset.p) el.onclick=()=>openProvider(el.dataset.p,list[i]);
  });
}
async function websiteSearch(q){
  const request=++state.searchRequest;
  state.query=q; goTo("website"); renderWebsitePage();
  if(!q){return;}
  $("#resultsArea").innerHTML=`<div class="loading">กำลังค้นหาเว็บไซต์…</div>`;
  try{
    const results=await fetchWebsites(q);
    if(request!==state.searchRequest || state.page!=="website")return;
    state.websiteResults=results; state.sourceErrors.website=""; renderWebsiteResults();
  }
  catch(e){
    if(request!==state.searchRequest || state.page!=="website")return;
    state.sourceErrors.website=e.message||"ค้นหาเว็บไซต์ไม่สำเร็จ";
    $("#resultsArea").innerHTML=`<div class="empty">ค้นหาเว็บไซต์ไม่สำเร็จ</div>`;
  }
}
async function fetchWebsites(q){
  const raw=q.trim();
  const directory=[
    ["Google","https://www.google.com/","google.com","ค้นหาเว็บ"],
    ["Google Maps","https://maps.google.com/","maps.google.com","แผนที่"],
    ["Google Drive","https://drive.google.com/","drive.google.com","ไฟล์"],
    ["Google News","https://news.google.com/","news.google.com","ข่าว"],
    ["YouTube","https://www.youtube.com/","youtube.com","วิดีโอ"],
    ["YouTube Music","https://music.youtube.com/","music.youtube.com","เพลง"],
    ["Facebook","https://www.facebook.com/","facebook.com","โซเชียล"],
    ["Spotify","https://open.spotify.com/","spotify.com","เพลง"],
    ["JOOX","https://www.joox.com/th/search","joox.com","เพลง"],
    ["Wikipedia","https://th.wikipedia.org/","wikipedia.org","สารานุกรม"],
    ["GitHub","https://github.com/","github.com","โค้ด"],
    ["Canva","https://www.canva.com/","canva.com","ออกแบบ"],
    ["TikTok","https://www.tiktok.com/","tiktok.com","วิดีโอสั้น"],
    ["Shopee","https://shopee.co.th/","shopee.co.th","ช้อปปิ้ง"],
    ["Lazada","https://www.lazada.co.th/","lazada.co.th","ช้อปปิ้ง"]
  ];
  const nq=raw.toLowerCase();
  const normalized=nq.replace(/^https?:\/\//,"").replace(/^www\./,"");
  const looksUrl=/^[a-z0-9-]+(\.[a-z0-9-]+)+([\/?#].*)?$/i.test(normalized);
  if(looksUrl){
    const url=/^https?:\/\//i.test(raw)?raw:"https://"+raw;
    return [{name:"เปิดเว็บไซต์",url,host:normalized.split("/")[0],description:"URL ที่ผู้ใช้ป้อน"}];
  }
  const scored=directory.map(([name,url,host,description])=>{
    const hay=(name+" "+host+" "+description).toLowerCase();
    let score=0;
    if(name.toLowerCase()===nq)score+=100;
    if(name.toLowerCase().startsWith(nq))score+=60;
    if(host.includes(normalized))score+=55;
    if(hay.includes(nq))score+=25;
    return {name,url,host,description,score};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,8).map(({score,...x})=>x);
  const searchUrl="https://www.google.com/search?q="+encodeURIComponent(raw);
  scored.push({name:"ค้นหาเว็บต่อด้วย Google",url:searchUrl,host:"google.com/search",description:"ผลเว็บจากคำค้นนี้"});
  return scored;
}
function renderWebsiteResults(){
  const area=$("#resultsArea"); if(!area)return;
  area.innerHTML=state.websiteResults.map(s=>`<article class="card website-row" data-url="${esc(s.url)}"><div class="site-icon">◎</div><div class="site-body"><div class="site-name">${esc(s.name)}</div><div class="site-url">${esc(s.host)}</div></div><span class="arrow">›</span></article>`).join("");
  area.querySelectorAll("[data-url]").forEach(el=>el.onclick=()=>openWebsite(el.dataset.url));
}
function openWebsite(url){state.currentWebsite=url;pushPage("webview")}
function renderHome(){
  view.innerHTML=`<section class="view">
    <div class="hero"><div class="logo">SB</div><h1>SupperBlack</h1><div class="subtitle">ค้นหาได้กว้าง ทุกเรื่องในแอปเดียว</div></div>
    ${searchBox()}
    <div class="quick-grid">
      <button class="quick youtube" id="quickYT">▶ YouTube</button>
      <button class="quick music" id="quickMusic">♫ เพลง</button>
      <button class="quick website" id="quickWeb">◎ เว็บไซต์</button>
    </div>
    <div class="section-head"><h2>ทางลัดยอดนิยม</h2><span class="muted">เฉพาะทาง</span></div>
    <div class="card">
      <div class="chips">
        <button class="chip" data-q="มือถือ Samsung S25">มือถือ</button>
        <button class="chip" data-q="เพลงเพื่อชีวิต">เพลง</button>
        <button class="chip" data-q="ข่าววันนี้">ข่าว</button>
        <button class="chip" data-q="เว็บไซต์">เว็บไซต์</button>
      </div>
    </div>
    <div class="section-head"><h2>หลักการ MVP</h2><span class="muted">เรียบง่าย / แก้ต่อได้</span></div>
    <div class="card muted">ค้นหา → แสดงผล → แตะเข้าไปดูต่อ → Back / Home กลับได้ โดยใช้หน้าเดียวและ state เดียวเป็นแกนหลัก</div>
  </section>`;
  bindSearch("global");
  $("#quickYT").onclick=()=>pushPage("youtube");
  $("#quickMusic").onclick=()=>pushPage("music");
  $("#quickWeb").onclick=()=>pushPage("website");
  document.querySelectorAll("[data-q]").forEach(b=>b.onclick=()=>globalSearch(b.dataset.q));
}
function renderResults(){
  const yt=state.youtubeResults.slice(0,4), mu=state.musicResults.slice(0,4), ws=state.websiteResults.slice(0,6);
  view.innerHTML=`<section class="view"><div class="section-head"><h2>ผลการค้นหา</h2><span class="muted">"${esc(state.query)}"</span></div>${searchBox({value:state.query})}
    <div class="section-head"><h2>▶ YouTube</h2><button class="btn secondary" id="moreYT">ดูทั้งหมด</button></div>
    <div>${yt.length?yt.map(v=>`<article class="card result-card" data-video="${esc(v.id)}"><img class="thumb" src="${esc(v.thumb)}"><div class="result-body"><div class="result-title">${esc(v.title)}</div><div class="result-meta">${esc(v.channel)}</div></div><span class="arrow">›</span></article>`).join(""):`<div class="empty">${state.sourceErrors.youtube?esc(state.sourceErrors.youtube):"ยังไม่มีผล YouTube"}${!localStorage.getItem("sb_youtube_api_key")?`<br><br><button class="btn primary" id="globalYTSettings">ตั้งค่า YouTube API Key</button>`:""}</div>`}</div>
    <div class="section-head"><h2>♫ เพลง</h2><button class="btn secondary" id="moreMusic">ดูทั้งหมด</button></div>
    <div id="musicResultsArea">${mu.length?mu.map((m,i)=>musicCardHtml(m,i)).join(""):`<div class="empty">${state.sourceErrors.music?esc(state.sourceErrors.music):"ไม่พบเพลง"}</div>`}</div>
    <div class="section-head"><h2>◎ เว็บไซต์</h2><button class="btn secondary" id="moreWeb">ดูทั้งหมด</button></div>
    <div class="card">${ws.map(s=>`<div class="website-row" data-url="${esc(s.url)}"><div class="site-icon">◎</div><div class="site-body"><div class="site-name">${esc(s.name)}</div><div class="site-url">${esc(s.host)}</div></div><span class="arrow">›</span></div>`).join("")}</div>
  </section>`;
  bindSearch("global");
  document.querySelectorAll("[data-video]").forEach(el=>el.onclick=()=>openVideo(el.dataset.video));
  document.querySelectorAll("[data-url]").forEach(el=>el.onclick=()=>openWebsite(el.dataset.url));
  const musicArea=$("#musicResultsArea"); if(musicArea) bindMusicCards(musicArea,mu);
  $("#moreYT").onclick=()=>youtubeSearch(state.query); $("#moreMusic").onclick=()=>musicSearch(state.query); $("#moreWeb").onclick=()=>websiteSearch(state.query);
  if($("#globalYTSettings"))$("#globalYTSettings").onclick=()=>$("#settingsBtn").click();
}
function renderWebview(){
  const url=state.currentWebsite;
  if(!url){state.page="home";render();return;}
  view.innerHTML=`<section class="view"><div class="section-head"><h2>◎ เว็บไซต์</h2><button class="btn secondary" id="external">เปิดภายนอก</button></div>
  <div class="web-warning">เว็บไซต์ปลายทางอาจไม่อนุญาตให้แสดงใน iframe หากไม่แสดงผล ให้ใช้ “เปิดภายนอก”</div>
  <div class="webview-shell"><iframe src="${esc(url)}" title="Website"></iframe></div></section>`;
  $("#external").onclick=()=>window.open(url,"_blank","noopener");
}
function renderResultsLoading(){
  view.innerHTML=`<section class="view"><div class="section-head"><h2>ผลการค้นหา</h2><span class="muted">"${esc(state.query)}"</span></div>${searchBox({value:state.query})}<div class="card"><div class="loading">กำลังค้นหา YouTube / เพลง / เว็บไซต์…</div></div></section>`;
  bindSearch("global");
}
function renderYoutubePage(){
  view.innerHTML=`<section class="view"><div class="section-head"><h2>▶ YouTube</h2><span class="muted">ค้นหาเฉพาะ YouTube</span></div>${searchBox({placeholder:"ค้นหา YouTube...",value:state.query})}<div id="resultsArea"><div class="empty">${state.query?"กำลังค้นหา…":"พิมพ์คำค้นหา YouTube แล้วกดค้นหา"}</div></div></section>`;
  bindSearch("youtube");
}
function renderMusicPage(){
  view.innerHTML=`<section class="view"><div class="section-head"><h2>♫ เพลง</h2><span class="muted">ค้นหาเฉพาะเพลง</span></div>${searchBox({placeholder:"ค้นหาเพลง / ศิลปิน / อัลบั้ม...",value:state.query})}<div id="resultsArea"><div class="empty">${state.query?"กำลังค้นหาเพลง…":"พิมพ์ชื่อเพลง ศิลปิน หรืออัลบั้ม"}</div></div></section>`;
  bindSearch("music");
}
function renderWebsitePage(){
  view.innerHTML=`<section class="view"><div class="section-head"><h2>◎ เว็บไซต์</h2><span class="muted">ค้นหาเว็บ / เปิด URL</span></div>${searchBox({placeholder:"เช่น google, facebook หรือ example.com",value:state.query})}<div id="resultsArea"><div class="empty">${state.query?"กำลังค้นหาเว็บไซต์…":"พิมพ์ชื่อเว็บหรือ URL ไม่เต็มก็ได้"}</div></div></section>`;
  bindSearch("website");
}
function render(){
  if(state.page==="home")renderHome();
  else if(state.page==="results"){
    if(state.youtubeResults.length || state.musicResults.length || state.websiteResults.length)renderResults();
    else renderResultsLoading();
  }
  else if(state.page==="youtube")renderYoutubePage();
  else if(state.page==="music")renderMusicPage();
  else if(state.page==="website")renderWebsitePage();
  else if(state.page==="player")renderPlayer();
  else if(state.page==="webview")renderWebview();
}
renderHome();
